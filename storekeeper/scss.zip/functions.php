<?php
		include "dbconf.php";
		
		include "process.php";
?>