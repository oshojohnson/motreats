<?php 
	echo md5("motbozz#1");
?>